﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IceCreamGUI
{
    public partial class EmpDashboard : Form
    {
        public EmpDashboard()
        {
            InitializeComponent();
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            new CheckOut().Show();
            this.Hide();
        }

        private void chkChocolate_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkVanilla_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkStrawberry_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkBanana_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkCoffee_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkSherbert_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkSprinkles_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkCookie_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkChocolateChip_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkOreos_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkCereal_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkNuts_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
