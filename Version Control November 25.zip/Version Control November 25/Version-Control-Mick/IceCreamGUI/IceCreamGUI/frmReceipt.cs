﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IceCreamGUI
{
    public partial class frmReceipt : Form
    {
        public frmReceipt()
        {
            InitializeComponent();
        }

        private void Checkout()
        {
            int iceCreamNum = 0;

            foreach (frmMain.IceCream I in frmMain.cart)
            {
                iceCreamNum++;

                lstSummary.Items.Add(("Ice Cream #" + iceCreamNum.ToString()));
                lstSummary.Items.Add((I.Size.ToString() + " " + I.Flavor.ToString()));
                lstSummary.Items.Add("Toppings:");


                foreach (frmMain.IceCream.toppingType topping in I.Toppings)
                    lstSummary.Items.Add(topping.ToString());
                lstSummary.Items.Add(("Item cost: " + I.Cost.ToString("C2")));
                lstSummary.Items.Add(" ");

            }

            double totalIceCream = 0.0;



            foreach (frmMain.IceCream icecream in frmMain.cart)
                totalIceCream += icecream.Cost;

            double tax = 8.25;
            double totalOrder = (totalIceCream * tax) / 100;

            txtSubTotal.Text = totalIceCream.ToString("C2");
            
            txtTax.Text = totalOrder.ToString("C2");
            txtTotalBalance.Text = (totalIceCream + totalOrder).ToString("C2");
        }
    }

    
}

